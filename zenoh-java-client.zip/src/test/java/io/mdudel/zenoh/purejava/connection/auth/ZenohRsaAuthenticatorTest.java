/*
 * Copyright 2026 the java-zenoh-publisher-pure contributors.
 * Licensed under the Apache License, Version 2.0. See LICENSE.
 */
package io.mdudel.zenoh.purejava.connection.auth;

import io.mdudel.zenoh.purejava.session.SessionException;
import io.mdudel.zenoh.purejava.session.SessionState;
import io.mdudel.zenoh.purejava.session.ZenohSession;
import io.mdudel.zenoh.purejava.session.Subscription;
import io.mdudel.zenoh.purejava.session.Sample;
import io.mdudel.zenoh.purejava.transport.PemLoader;
import io.mdudel.zenoh.purejava.transport.Transport;
import io.mdudel.zenoh.purejava.transport.TransportException;
import io.mdudel.zenoh.purejava.wire.Extension;
import io.mdudel.zenoh.purejava.wire.RBuf;
import io.mdudel.zenoh.purejava.wire.WBuf;

import javax.crypto.Cipher;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.Base64;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/** Dependency-free executable tests; run with assertions handled explicitly. */
public final class ZenohRsaAuthenticatorTest {
    public static void main(String[] args) throws Exception {
        roundTripsOfficialChallengeFlow();
        rejectsUntrustedRouter();
        rejectsMismatchedKeyPair();
        loadsSubjectPublicKeyInfoAndPkcs8Pem();
        integratesWithFullSessionHandshake();
        System.out.println("ZenohRsaAuthenticatorTest: all tests passed");
    }

    private static void roundTripsOfficialChallengeFlow() throws Exception {
        KeyPair client = rsa();
        KeyPair router = rsa();
        ZenohRsaAuthenticator auth = authenticator(client, Set.of(identity(router)));

        List<Extension> init = auth.initSynExtensions();
        RSAPublicKey sentClientKey = decodeInitSynPublicKey(init);
        check(sentClientKey.getModulus().equals(((RSAPublicKey) client.getPublic()).getModulus()),
                "InitSyn did not contain client public key");

        byte[] nonce = new byte[]{1, 3, 3, 7, 9, 2, 4, 8};
        Cipher encryptForClient = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        encryptForClient.init(Cipher.ENCRYPT_MODE, client.getPublic());
        auth.receiveInitAck(initAck(router, encryptForClient.doFinal(nonce)));

        byte[] response = decodeOpenSynResponse(auth.openSynExtensions());
        Cipher decryptAtRouter = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        decryptAtRouter.init(Cipher.DECRYPT_MODE, router.getPrivate());
        check(java.util.Arrays.equals(nonce, decryptAtRouter.doFinal(response)),
                "OpenSyn did not return the router-encrypted nonce");

        auth.receiveOpenAck(openAck());
    }

    private static void rejectsUntrustedRouter() throws Exception {
        KeyPair client = rsa();
        KeyPair trusted = rsa();
        KeyPair impostor = rsa();
        ZenohRsaAuthenticator auth = authenticator(client, Set.of(identity(trusted)));
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, client.getPublic());
        expect(SessionException.class,
                () -> auth.receiveInitAck(initAck(impostor, cipher.doFinal(new byte[8]))));
    }

    private static void rejectsMismatchedKeyPair() throws Exception {
        KeyPair first = rsa();
        KeyPair second = rsa();
        expect(IllegalArgumentException.class, () -> new ZenohRsaAuthenticator(
                (RSAPublicKey) first.getPublic(), (RSAPrivateKey) second.getPrivate(), Set.of()));
    }

    private static void loadsSubjectPublicKeyInfoAndPkcs8Pem() throws Exception {
        KeyPair pair = rsa();
        Path dir = Files.createTempDirectory("zenoh-rsa-pem-test");
        Path publicPem = dir.resolve("public.pem");
        Path privatePem = dir.resolve("private.pem");
        Files.writeString(publicPem, pem("PUBLIC KEY", pair.getPublic().getEncoded()), StandardCharsets.US_ASCII);
        Files.writeString(privatePem, pem("PRIVATE KEY", pair.getPrivate().getEncoded()), StandardCharsets.US_ASCII);
        check(PemLoader.readPublicKey(publicPem) instanceof RSAPublicKey, "public PEM was not RSA");
        check(PemLoader.readPrivateKey(privatePem) instanceof RSAPrivateKey, "private PEM was not RSA");
        new ZenohRsaAuthenticator(publicPem, privatePem);
    }

    private static void integratesWithFullSessionHandshake() throws Exception {
        KeyPair client = rsa();
        KeyPair router = rsa();
        ZenohRsaAuthenticator auth = authenticator(client, Set.of(identity(router)));
        byte[] nonce = new byte[]{8, 6, 7, 5, 3, 0, 9, 1};
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, client.getPublic());
        ScriptedTransport transport = new ScriptedTransport(
                encodeInitAck(initAck(router, cipher.doFinal(nonce))), encodeOpenAck(openAck()));
        ZenohSession session = ZenohSession.builder(transport)
                .authenticator(auth).autoConnect(true).build();
        session.open();
        check(session.state() == SessionState.OPEN, "authenticated session did not open");
        check(transport.sent.size() == 2, "expected InitSyn and OpenSyn");
        check((transport.sent.get(0)[0] & 0x80) != 0, "InitSyn did not advertise extensions");
        check((transport.sent.get(1)[0] & 0x80) != 0, "OpenSyn did not advertise extensions");
        Subscription subscription = session.declareSubscriber("org/lattice/entities");
        session.publishString("org/lattice/entities", "entity");
        Sample local = subscription.poll(1, TimeUnit.SECONDS);
        check(local != null, "same-session publication was not routed locally");
        check("entity".equals(local.payloadAsString()), "local publication payload mismatch");
        session.close();
    }

    private static byte[] encodeInitAck(List<Extension> extensions) {
        WBuf out = new WBuf();
        out.u8(0x01 | 0x20 | 0x80);
        out.u8(ZenohSession.WIRE_VERSION);
        out.u8(0);
        out.u8(0x2a);
        out.lenBytes(new byte[]{4, 2});
        Extension.writeAll(extensions, out);
        return out.toByteArray();
    }

    private static byte[] encodeOpenAck(List<Extension> extensions) {
        WBuf out = new WBuf();
        out.u8(0x02 | 0x20 | 0x80);
        out.varInt(10_000);
        out.varInt(0);
        Extension.writeAll(extensions, out);
        return out.toByteArray();
    }

    private static ZenohRsaAuthenticator authenticator(KeyPair pair,
            Set<ZenohRsaAuthenticator.RsaIdentity> trusted) {
        return new ZenohRsaAuthenticator((RSAPublicKey) pair.getPublic(),
                (RSAPrivateKey) pair.getPrivate(), trusted);
    }

    private static ZenohRsaAuthenticator.RsaIdentity identity(KeyPair pair) {
        RSAPublicKey key = (RSAPublicKey) pair.getPublic();
        return new ZenohRsaAuthenticator.RsaIdentity(key.getModulus(), key.getPublicExponent());
    }

    private static List<Extension> initAck(KeyPair router, byte[] encryptedNonce) {
        RSAPublicKey key = (RSAPublicKey) router.getPublic();
        WBuf body = new WBuf();
        body.lenBytes(ZenohRsaAuthenticator.toLittleEndian(key.getModulus()));
        body.lenBytes(ZenohRsaAuthenticator.toLittleEndian(key.getPublicExponent()));
        body.lenBytes(encryptedNonce);
        return outer(Extension.zbuf(ZenohRsaAuthenticator.PUBKEY_AUTH_ID, false, body.toByteArray()));
    }

    private static List<Extension> openAck() {
        return outer(Extension.unit(ZenohRsaAuthenticator.PUBKEY_AUTH_ID, false));
    }

    private static List<Extension> outer(Extension mechanism) {
        WBuf list = new WBuf();
        list.varInt(1);
        Extension.writeAll(List.of(mechanism), list);
        return List.of(Extension.zbuf(ZenohRsaAuthenticator.OUTER_AUTH_ID, false, list.toByteArray()));
    }

    private static RSAPublicKey decodeInitSynPublicKey(List<Extension> extensions) throws Exception {
        byte[] body = innerBody(extensions).asZBuf();
        RBuf reader = new RBuf(body);
        java.math.BigInteger n = ZenohRsaAuthenticator.fromLittleEndian(reader.lenBytes());
        java.math.BigInteger e = ZenohRsaAuthenticator.fromLittleEndian(reader.lenBytes());
        return (RSAPublicKey) java.security.KeyFactory.getInstance("RSA")
                .generatePublic(new java.security.spec.RSAPublicKeySpec(n, e));
    }

    private static byte[] decodeOpenSynResponse(List<Extension> extensions) {
        return new RBuf(innerBody(extensions).asZBuf()).lenBytes();
    }

    private static Extension innerBody(List<Extension> extensions) {
        RBuf list = new RBuf(extensions.get(0).asZBuf());
        check(list.varInt() == 1, "expected one auth mechanism");
        return Extension.readAll(list).get(0);
    }

    private static KeyPair rsa() throws Exception {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048);
        return generator.generateKeyPair();
    }

    private static String pem(String label, byte[] der) {
        return "-----BEGIN " + label + "-----\n"
                + Base64.getMimeEncoder(64, new byte[]{'\n'}).encodeToString(der)
                + "\n-----END " + label + "-----\n";
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static void expect(Class<? extends Throwable> type, Throwing action) throws Exception {
        try { action.run(); }
        catch (Throwable value) {
            if (type.isInstance(value)) return;
            throw new AssertionError("expected " + type.getName() + ", got " + value, value);
        }
        throw new AssertionError("expected " + type.getName() + " but nothing was thrown");
    }

    @FunctionalInterface private interface Throwing { void run() throws Exception; }

    private static final class ScriptedTransport implements Transport {
        private final java.util.concurrent.BlockingQueue<byte[]> replies =
                new java.util.concurrent.LinkedBlockingQueue<>();
        private final List<byte[]> sent = new java.util.ArrayList<>();
        private boolean open;
        ScriptedTransport(byte[]... replies) { this.replies.addAll(List.of(replies)); }
        @Override public void connect() { open = true; }
        @Override public void send(byte[] batch) throws TransportException {
            if (!open) throw new TransportException("closed");
            sent.add(batch.clone());
        }
        @Override public byte[] receive(long timeout, TimeUnit unit) throws InterruptedException {
            return replies.poll(timeout, unit);
        }
        @Override public boolean isOpen() { return open; }
        @Override public String describe() { return "scripted/test"; }
        @Override public void close() { open = false; }
    }
}
