package io.mdudel.zenoh.purejava.wire.messages;
import java.util.List;
import io.mdudel.zenoh.purejava.wire.RBuf;
/** Dependency-free regression tests; run with java -ea. */
public final class DeclareKeyExprTest {
 public static void main(String[] args){
  DeclareKeyExpr add=new DeclareKeyExpr(7,0,"org/events",List.of());
  Declare decoded=Declare.decode(new Declare(null,List.of(),Declare.Body.of(add)).encode());
  assert decoded.body().kind()==Declare.Body.BodyKind.DECLARE_KEY_EXPR;
  assert decoded.body().asDeclareKeyExpr().equals(add);
  UndeclareKeyExpr remove=new UndeclareKeyExpr(7,List.of());
  decoded=Declare.decode(new Declare(null,List.of(),Declare.Body.of(remove)).encode());
  assert decoded.body().kind()==Declare.Body.BodyKind.UNDECLARE_KEY_EXPR;
  assert decoded.body().asUndeclareKeyExpr().equals(remove);
  Push compact=new Push(7,"/temperature",true,List.of(),Put.ofBytes(new byte[]{1}).encode());
  Push roundTrip=Push.decode(compact.encode());
  assert roundTrip.keyScope()==7&&"/temperature".equals(roundTrip.keySuffix());

  byte[] first=new Declare(null,List.of(),Declare.Body.of(add)).encode();
  byte[] second=compact.encode();
  byte[] framePayload=new byte[first.length+second.length];
  System.arraycopy(first,0,framePayload,0,first.length);
  System.arraycopy(second,0,framePayload,first.length,second.length);
  RBuf cursor=new RBuf(framePayload);
  assert Declare.decode(cursor).body().asDeclareKeyExpr().equals(add);
  assert Push.decode(cursor).keyScope()==7;
  assert !cursor.hasMore();
  System.out.println("DeclareKeyExprTest: all tests passed");
 }
}
